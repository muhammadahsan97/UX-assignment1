# Resume - CV 

My resume/CV in [Bootstrap](http://getbootstrap.com/).
Essentially taken from [this template](https://startbootstrap.com/template-overviews/resume/) created by [Start Bootstrap](http://startbootstrap.com/). 

## Preview

[![Resume Preview](https://raw.githubusercontent.com/fabriziomiano/fabriziomiano.github.io/master/resume.png)](https://raw.githubusercontent.com/fabriziomiano/fabriziomiano.github.io/master/resume.png)

**[View Live Preview](https://fabriziomiano.github.io/)**
